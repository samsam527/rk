#include "EquaDiff.h"

EquaDiff::EquaDiff()
{
    //ctor
}

EquaDiff::~EquaDiff()
{
    //dtor
}
